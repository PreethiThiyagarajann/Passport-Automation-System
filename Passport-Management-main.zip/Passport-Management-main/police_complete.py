'''executing all the police table commands'''
exec(open('police_table.py').read())

'''executing the police login'''
exec(open('police_login.py').read())
