'''executing the admin commands'''
exec(open('admin_table.py').read())

'''executing the police commands'''
exec(open('police_table.py').read())

'''executing the user commands'''
exec(open('user_table.py').read())

print("setup complete")