'''executing all the admin table commands'''
exec(open('admin_table.py').read())

'''executing the admin login'''
exec(open('admin_login.py').read())
